/** 
  *
  * Biblioteca Dumotor
  * @autor Duane oliveira
  * 
  **/


#ifndef Dumotor_H
#define Dumotor_H

#include "Arduino.h"

class Dumotor 
{
public:

    Dumotor();

    void M1move(int velocidade, int sentido ,int sentidoc);
    void M1parar();
    void M2move(int velocidade, int sentido ,int sentidoc);
    void M2parar();
    
private:

    int pwmPinM1;
    int sentidoPinM1;
    int sentidoPinM1c;
	int pwmPinM2;
	int sentidoPinM2;
        int sentidoPinM2c;
};

#endif