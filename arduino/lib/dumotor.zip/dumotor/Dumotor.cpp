/**
  *
  * Biblioteca Dumotor
  * @autor Duane Oliveira
  *
  *
  **/


#include "Dumotor.h"
#include "Arduino.h"

Dumotor::Dumotor()
{
	pwmPinM1=9;
    sentidoPinM1=8;
    sentidoPinM1c=7;
	pwmPinM2=6;
     sentidoPinM2c=5;
	sentidoPinM2=4;

	pinMode(pwmPinM1, OUTPUT);
	pinMode(pwmPinM2, OUTPUT);
	pinMode(sentidoPinM1, OUTPUT);
	pinMode(sentidoPinM2, OUTPUT);
     pinMode(sentidoPinM1c, OUTPUT);
	pinMode(sentidoPinM2c, OUTPUT);

}

void Dumotor::M1move(int velocidade, int sentido,int sentidoc)
{
    analogWrite(pwmPinM1, velocidade);
    digitalWrite(sentidoPinM1, sentido);
    digitalWrite(sentidoPinM1c, sentidoc);
}

void Dumotor::M1parar()
{
    analogWrite(pwmPinM1, 0);
}

void Dumotor::M2move(int velocidade, int sentido,int sentidoc)
{
	analogWrite(pwmPinM2, velocidade);
    digitalWrite(sentidoPinM2, sentido);
    digitalWrite(sentidoPinM2c, sentidoc);
}

void Dumotor::M2parar()
{
    analogWrite(pwmPinM2, 0);
}
